package isp;

import fri.isp.Agent;
import fri.isp.Environment;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;

/**
 * TASK:
 * Assuming Alice and Bob know a shared secret key, secure the channel using a
 * AES in GCM. Then exchange ten messages between Alice and Bob.
 * <p>
 * https://docs.oracle.com/en/java/javase/11/docs/api/java.base/javax/crypto/Cipher.html
 */
public class A1AgentCommunicationGCM {
    public static void main(String[] args) throws Exception {
        /*
         * Alice and Bob share a secret session key that will be
         * used for AES in GCM.
         */
        final SecretKey key = KeyGenerator.getInstance("AES").generateKey();

        final Environment env = new Environment();

        env.add(new Agent("alice") {
            @Override
            public void task() throws Exception {
                for (int i = 0; i < 10; i++) {
                    final String text = "Message " + (i + 1) + " from Alice";
                    final byte[] pt = text.getBytes(StandardCharsets.UTF_8);

                    // Encrypt
                    final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                    cipher.init(Cipher.ENCRYPT_MODE, key);
                    final byte[] ct = cipher.doFinal(pt);
                    final byte[] iv = cipher.getIV();

                    // Send IV and ciphertext
                    send("bob", iv);
                    send("bob", ct);
                }
            }
        });

        env.add(new Agent("bob") {
            @Override
            public void task() throws Exception {
                for (int i = 0; i < 10; i++) {
                    // Receive IV and ciphertext
                    final byte[] iv = receive("alice");
                    final byte[] ct = receive("alice");

                    // Decrypt
                    final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                    final GCMParameterSpec specs = new GCMParameterSpec(128, iv);
                    cipher.init(Cipher.DECRYPT_MODE, key, specs);
                    final byte[] pt = cipher.doFinal(ct);

                    final String message = new String(pt, StandardCharsets.UTF_8);
                    System.out.printf("Received by Bob: %s%n", message);
                }
            }
        });

        env.connect("alice", "bob");
        env.start();
    }
}