package isp;

import fri.isp.Agent;
import fri.isp.Environment;

import javax.crypto.Cipher;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;

public class A3AgentCommunicationRSA {
    public static void main(String[] args) throws Exception {

        final KeyPair aliceKP = KeyPairGenerator.getInstance("RSA").generateKeyPair();
        final KeyPair bobKP = KeyPairGenerator.getInstance("RSA").generateKeyPair();

        final Environment env = new Environment();

        env.add(new Agent("alice") {
            @Override
            public void task() throws Exception {
                // Create an RSA cipher and encrypt a message using Bob's PK
                Cipher cipher = Cipher.getInstance("RSA");
                cipher.init(Cipher.ENCRYPT_MODE, bobKP.getPublic());
                String message = "Hello Bobby, this is Alice.";
                byte[] ct = cipher.doFinal(message.getBytes(StandardCharsets.UTF_8));

                // Send the CT to Bob
                send("bobby", ct);
            }
        });

        env.add(new Agent("bobby") {
            @Override
            public void task() throws Exception {
                // Take the incoming message from the queue
                byte[] ct = receive("alice");

                // Create an RSA cipher and decrypt incoming CT using Bob's SK
                Cipher cipher = Cipher.getInstance("RSA");
                cipher.init(Cipher.DECRYPT_MODE, bobKP.getPrivate());
                byte[] pt = cipher.doFinal(ct);

                // Print the message
                String message = new String(pt, StandardCharsets.UTF_8);
                System.out.println("Received by Bobby: " + message);
            }
        });

        env.connect("alice", "bobby");
        env.start();
    }
}