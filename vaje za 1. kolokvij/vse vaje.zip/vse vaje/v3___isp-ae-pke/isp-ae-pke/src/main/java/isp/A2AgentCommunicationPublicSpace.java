/**
 * TASK:
 * We want to send a large chunk of data from Alice to Bob while maintaining its integrity and considering
 * the limitations of communication channels -- we have three such channels:
 * - Alice to Bob: an insecure channel, but has high bandwidth and can thus transfer large files
 * - Alice to Public Space: a secure channel, but has low bandwidth and can only transfer small amounts of data
 * - Bob to Public Space: a secure channel, but has low bandwidth and can only transfer small amounts of data
 * <p>
 * The plan is to make use of the public-space technique:
 * - Alice creates the data and computes its digest
 * - Alice sends the data to Bob, and sends the encrypted digest to Public Space
 * - Channel between Alice and Public space is secured with ChaCha20-Poly1305 (Alice and Public space share
 * a ChaCha20 key)
 * - Public space forwards the digest to Bob
 * - The channel between Public Space and Bob is secured but with AES in GCM mode (Bob and Public space share
 * an AES key)
 * - Bob receives the data from Alice and the digest from Public space
 * - Bob computes the digest over the received data and compares it to the received digest
 * <p>
 * Further instructions are given below.
 * <p>
 * https://docs.oracle.com/en/java/javase/11/docs/api/java.base/javax/crypto/Cipher.html
 */
package isp;

import fri.isp.Agent;
import fri.isp.Environment;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;

public class A2AgentCommunicationPublicSpace {
    public static void main(String[] args) throws Exception {
        final Environment env = new Environment();

        // Create a ChaCha20 key that is used by Alice and the public-space
        final SecretKey chachaKey = KeyGenerator.getInstance("ChaCha20").generateKey();
        // Create an AES key that is used by Bob and the public-space
        final SecretKey aesKey = KeyGenerator.getInstance("AES").generateKey();

        env.add(new Agent("alice") {
            @Override
            public void task() throws Exception {
                // a payload of 200 MB
                final byte[] data = new byte[200 * 1024 * 1024];
                new SecureRandom().nextBytes(data);

                // Alice sends the data directly to Bob
                send("bob", data);

                // Alice then computes the digest of the data
                MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
                byte[] digest = sha256.digest(data);

                // Encrypt the digest with ChaCha20-Poly1305
                Cipher cipher = Cipher.getInstance("ChaCha20-Poly1305");
                byte[] iv = new byte[12]; // ChaCha20-Poly1305 requires a 12-byte IV
                new SecureRandom().nextBytes(iv);
                cipher.init(Cipher.ENCRYPT_MODE, chachaKey, new IvParameterSpec(iv));
                byte[] encryptedDigest = cipher.doFinal(digest);

                // Send the IV and encrypted digest to public-space
                send("public-space", iv);
                send("public-space", encryptedDigest);
            }
        });

        env.add(new Agent("public-space") {
            @Override
            public void task() throws Exception {
                // Receive the IV and encrypted digest from Alice
                byte[] iv = receive("alice");
                byte[] encryptedDigest = receive("alice");

                // Decrypt the digest with ChaCha20-Poly1305
                Cipher cipher = Cipher.getInstance("ChaCha20-Poly1305");
                cipher.init(Cipher.DECRYPT_MODE, chachaKey, new IvParameterSpec(iv));
                byte[] digest = cipher.doFinal(encryptedDigest);

                // Encrypt the digest with AES-GCM
                cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, aesKey);
                byte[] aesEncryptedDigest = cipher.doFinal(digest);
                byte[] aesIv = cipher.getIV();

                // Send the IV and encrypted digest to Bob
                send("bob", aesIv);
                send("bob", aesEncryptedDigest);
            }
        });

        env.add(new Agent("bob") {
            @Override
            public void task() throws Exception {
                // Receive the data from Alice
                byte[] data = receive("alice");

                // Compute the digest over the received data using SHA-256
                MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
                byte[] computedDigest = sha256.digest(data);

                // Receive the IV and encrypted digest from the public-space
                byte[] aesIv = receive("public-space");
                byte[] aesEncryptedDigest = receive("public-space");

                // Decrypt the digest with AES-GCM
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, aesKey, new GCMParameterSpec(128, aesIv));
                byte[] receivedDigest = cipher.doFinal(aesEncryptedDigest);

                // Compare the computed digest and the received digest
                if (Arrays.equals(computedDigest, receivedDigest)) {
                    System.out.println("data valid");
                } else {
                    System.out.println("data invalid");
                }
            }
        });

        env.connect("alice", "bob");
        env.connect("alice", "public-space");
        env.connect("public-space", "bob");
        env.start();
    }
}