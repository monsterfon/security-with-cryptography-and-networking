package isp.handson;

import fri.isp.Agent;
import fri.isp.Environment;

import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

public class Midterm0 {
    public static Key key;
    public static Mac alice;
    public static Mac bob;

    public static void main(String[] args) throws Exception {
        Environment env = new Environment();

        key = KeyGenerator.getInstance("HmacSHA256").generateKey();
        alice = Mac.getInstance("HmacSHA256");
        bob = Mac.getInstance("HmacSHA256");

        env.add(new Agent("alice") {
            public void task() throws Exception {
                for (int i = 0; i < 10; i++) {
                    final String text = "I hope you get this message intact. Kisses, Alice.";
                    //i know salt should be a random value, but  I didn't have the time to implement it
                    final byte[] tag = mac(text.getBytes(StandardCharsets.UTF_8), "PWD", "salt".getBytes(StandardCharsets.UTF_8));

                    send("server", text.getBytes(StandardCharsets.UTF_8));
                    send("server", tag);

                    final byte[] responseTextBytes = receive("server");
                    final byte[] responseHmacBytes = receive("server");

                    if (verify(responseTextBytes, responseHmacBytes, "PWD", "salt".getBytes(StandardCharsets.UTF_8))) {
                        System.out.println("SUCCESS: Alice: Integrity verified for Bob's response - " + new String(responseTextBytes, StandardCharsets.UTF_8));
                    } else {
                        System.out.println("FAILURE: Alice: Integrity check failed for Bob's response!");
                    }
                }
            }
        });

        env.add(new Agent("server") {
            public void task() throws Exception {
                for (int i = 0; i < 10; i++) {
                    final byte[] receivedTextBytes = receive("alice");
                    final byte[] receivedHmacBytes = receive("alice");

                    if (verify(receivedTextBytes, receivedHmacBytes, "PWD", "salt".getBytes(StandardCharsets.UTF_8))) {
                        System.out.println("SUCCESS: server -- Integrity verified for Alice's message - " + new String(receivedTextBytes, StandardCharsets.UTF_8));

                        final String responseText = "ok, Alice!";
                        final byte[] responseHmac = mac(responseText.getBytes(StandardCharsets.UTF_8), "PWD", "salt".getBytes(StandardCharsets.UTF_8));

                        send("alice", responseText.getBytes(StandardCharsets.UTF_8));
                        send("alice", responseHmac);
                    } else {
                        System.out.println("FAILURE server -- Integrity check failed for Alice's message!");
                    }
                }
            }
        });

        env.connect("alice", "server");
        env.start();
    }



    public static byte[] mac(byte[] payload, String password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256"); // password based key
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 256);
        SecretKeySpec secretKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "HmacSHA256");

        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKey);

        return mac.doFinal(payload);
    }


    public static boolean verify(byte[] payload, byte[] tag, String password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 256);
        SecretKeySpec secretKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "HmacSHA256");

        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKey);

        byte[] computedTag = mac.doFinal(payload);

        return MessageDigest.isEqual(computedTag, tag);
    }
}