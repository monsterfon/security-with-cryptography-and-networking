package isp.kolokvij;

import fri.isp.Agent;
import fri.isp.Environment;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileAlreadyExistsException;
import java.security.*;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECParameterSpec;
import java.security.spec.KeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.EventListener;

public class Midterm_MK {

    public static byte[] mac(byte[] payload, String password, byte[] salt) throws Exception {

        SecretKeyFactory pbkdf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 1000, 128);
        SecretKey derivedKey = pbkdf.generateSecret(spec);

        Key key = new SecretKeySpec(derivedKey.getEncoded(), "HmacSHA256");

        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(key);

        return mac.doFinal(payload);
    }

    public static boolean verify(byte[] payload, byte[] tag, String password, byte[] salt) throws Exception {
        byte[] expectedTag = mac(payload, password, salt);

        if (Arrays.equals(expectedTag, tag)) {
            //System.out.println("SUCCESS");
            return true;
        }
        else {
            //System.out.println("FAILURE");
            return false;
        }
    }

    public static byte[] hash(int times, byte[] payload) throws Exception{
        final MessageDigest digestAlgorithm = MessageDigest.getInstance("SHA-256");
        byte[] result = payload;

        for (int i = 0; i < times; i++) {
            result = digestAlgorithm.digest(result);
        }

        return result;
    }

    public static void main(String[] args) throws Exception {

        final SecretKey sharedKey = KeyGenerator.getInstance("AES").generateKey();
        final SecretKey sharedKeyServerLock = KeyGenerator.getInstance("AES").generateKey();


        Environment env = new Environment();

        byte[] secret = new byte[32];  // 32 bytes for SHA256
        new SecureRandom().nextBytes(secret);

        String SHARED_PASSWORD = "12345678";

        final KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
        kpg.initialize(256);

        // Generate key pair
        final KeyPair keyPairServer = kpg.generateKeyPair();

        final KeyPair keyPairAlice = kpg.generateKeyPair();

        env.add(new Agent("alice") {
            private String password = "test";
            public void task() throws Exception {

                byte[] salt = new byte[16];
                new SecureRandom().nextBytes(salt);
                byte[] currentToken = secret;

                byte[] token = hash(1000, password.getBytes());

                byte[][] tokenChain = new byte[1001][]; // Store all tokens

                for (int i = 0; i <= 1000; i++) {
                    currentToken = hash(1, currentToken); // Hash the token
                    tokenChain[i] = currentToken;         // Store in the chain
                }

                //byte[] tag = mac(token, password, salt);

                System.out.println(Arrays.toString(token));

                final Cipher cp = Cipher.getInstance("AES/GCM/NoPadding");
                cp.init(Cipher.ENCRYPT_MODE, sharedKey);
                final byte[] ct = cp.doFinal(token);
                final byte[] iv = cp.getIV();

                send("server", keyPairAlice.getPublic().getEncoded());
                final X509EncodedKeySpec keySpec = new X509EncodedKeySpec(receive("server"));
                final ECPublicKey bobPK = (ECPublicKey) KeyFactory.getInstance("EC").generatePublic(keySpec);

                final KeyAgreement dh = KeyAgreement.getInstance("ECDH");
                dh.init(keyPairAlice.getPrivate());
                dh.doPhase(bobPK, true);


                send("server", ct);
                send("server", iv);
            }
        });
        env.add(new Agent("server") {
            public void task() throws Exception {

                final X509EncodedKeySpec keySpec = new X509EncodedKeySpec(receive("alice"));
                final ECPublicKey alicePK = (ECPublicKey) KeyFactory.getInstance("EC").generatePublic(keySpec);

                final ECParameterSpec dhParamSpec = alicePK.getParams();

                // create your own DH key pair
                final KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
                kpg.initialize(dhParamSpec);
                final KeyPair keyPair = kpg.generateKeyPair();
                send("alice", keyPair.getPublic().getEncoded());

                final KeyAgreement dh = KeyAgreement.getInstance("ECDH");
                dh.init(keyPair.getPrivate());
                dh.doPhase(alicePK, true);


                // Generate salt for MAC computation
                byte[] salt = new byte[16];
                SecureRandom.getInstanceStrong().nextBytes(salt);

                // Receive encrypted token and IV from Alice
                final byte[] ct_r = receive("alice");
                final byte[] iv_r = receive("alice");

                // Decrypt token using AES-GCM
                final Cipher server = Cipher.getInstance("AES/GCM/NoPadding");
                final GCMParameterSpec specs = new GCMParameterSpec(128, iv_r);
                server.init(Cipher.DECRYPT_MODE, sharedKey, specs);
                final byte[] pt2 = server.doFinal(ct_r);  // Decrypted token (plaintext)

                // Compute MAC tag using the shared password and salt
                byte[] x = mac(pt2, SHARED_PASSWORD, salt);

                // Send the token, MAC tag, and salt to the lock
                send("lock", pt2);  // Send the plaintext token
                send("lock", x);    // Send the computed MAC tag
                send("lock", salt); // Send the salt for verification
            }
        });


        env.add(new Agent("lock") {
            public void task() throws Exception {
                //byte[] token = receive("alice");
                byte[] token_server = receive("server");
                byte[] tag_server = receive("server");
                byte[] salt_server = receive("server");

                byte[] storedToken = null;

                if(verify(token_server, tag_server, SHARED_PASSWORD, salt_server)) {
                    System.out.println("SERVER TOKEN VERIFIED");
                    storedToken = token_server;

                }
                else {
                    System.out.println("SERVER TOKEN NOT VERIFIED");
                }

                byte[] receivedToken = receive("alice");

                byte[] hashedToken = hash(1, receivedToken);
                if (Arrays.equals(hashedToken, storedToken)) {
                    System.out.println("ACCESS GRANTED");
                    storedToken = receivedToken;
                } else {
                    System.out.println("ACCESS DENIED");
                }
            }
        });



        env.connect("alice", "server");
        env.connect("server", "lock");
        env.connect("alice", "lock");


        env.start();
    }
}
