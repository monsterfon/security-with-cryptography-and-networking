package isp.handson;

import java.nio.charset.StandardCharsets;
import java.security.spec.InvalidKeySpecException;
import java.security.*;
import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;


import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.GCMParameterSpec;
import java.security.Key;


import java.security.KeyPair;
import java.security.KeyPairGenerator;


import fri.isp.Agent;
import fri.isp.Environment;


import java.security.SecureRandom;

public class Midterm {
        public static String pwd_S_L = "PWD_SERVER_LOCK";

        public static void main(String[] args) throws Exception {
        Environment env = new Environment();

        //key for sending hash
        final Key key = KeyGenerator.getInstance("AES").generateKey();
        //the symetric key to be sent over rsa
        final Key key2 = KeyGenerator.getInstance("AES").generateKey();
        //Define the public-secret key pairs globally in the main method.
        final KeyPair aliceKP = KeyPairGenerator.getInstance("RSA").generateKeyPair();
        final KeyPair bobKP = KeyPairGenerator.getInstance("RSA").generateKeyPair();

            env.add(new Agent("alice") {
            public void task() throws Exception {
                // sending token to server, so he can open the lock
                final String text = "TOKEN.";
                final byte[] salt = new byte[16];
                new SecureRandom().nextBytes(salt);
                print("Salt: %s", hex(salt));
                final byte[] tag = mac(text.getBytes(StandardCharsets.UTF_8), "PWD_A_S", salt);
                send("server", text.getBytes(StandardCharsets.UTF_8));
                send("server", tag);
                send("server", salt);

                // sending hash with authentification and encryption
                final String texty = "I hope you get this message intact and in secret. Kisses, Alice." ;
                byte[] pt = texty.getBytes(StandardCharsets.UTF_8);
                //rabimo poslat hash
                pt = hash(1000, pt);
                final Cipher alice = Cipher.getInstance("AES/GCM/NoPadding");
                alice.init(Cipher.ENCRYPT_MODE, key);
                byte[] ct = alice.doFinal(pt);
                final byte[] iv = alice.getIV();
                send("server", ct);
                send("server", iv);


                // sending key with rsa NALOGA 4
                // pise shared secret pa forward secrecy,
                // najprej pise da naredis z rsa.  potem pa diffie hellman,  ker edino ta da forward secrecy
                //prav bi bilo da bi z diffie hellman naredil
                final byte[] key2Bytes = key2.getEncoded();
                final Cipher rsaEnc = Cipher.getInstance("RSA");
                rsaEnc.init(Cipher.ENCRYPT_MODE, bobKP.getPublic());
                ct = rsaEnc.doFinal(key2Bytes);
                print("PT_RSA: " + Agent.hex(key2.getEncoded()));
                send("server", ct);

                /*
                Ostale naloge
                 Naloga5/6
                 token 1000krat hasham z sha256
                 privat ključ nrdim,
                 token pošljem z hmac do serverja
                 send same hmac to lock
                 lock preracuna svoj hmac z istim private keyom
                 pol pa primerja če je isti
                če  nocemo da ma svoj private, ima lahko lock samo shranjen svoj  hash code
                */




            }
        });
        env.add(new Agent("server") {
            public void task() throws Exception {

                // receiving token from alice and sending it to lock
                final byte[] receivedTextBytes = receive("alice");
                byte[] taggy = receive("alice");
                final byte[] salt = receive("alice");
                if (verify(receivedTextBytes, taggy, "PWD_A_S", salt)) {
                    print("SUCCESS:  -- Integrity verified for Alice's message - " + new String(receivedTextBytes, StandardCharsets.UTF_8));
                } else {
                    print("FAILURE -- Integrity check failed for Alice's message!");
                }
                taggy = mac(receivedTextBytes, pwd_S_L, salt);
                send("lock", receivedTextBytes);
                send("lock", taggy);
                send("lock", salt);



                // receiving hash from alice and decrypting it
                final byte[] text_rec = receive("alice");
                final byte[] iv_rec = receive("alice");
                final Cipher bob = Cipher.getInstance("AES/GCM/NoPadding");
                final GCMParameterSpec specs = new GCMParameterSpec(128, iv_rec);
                bob.init(Cipher.DECRYPT_MODE, key, specs);
                final byte[] pt2 = bob.doFinal(text_rec);
                print("SUCCESS: Hash of message: %s%n", new String(pt2, StandardCharsets.UTF_8));


                // receive key with rsa
                final byte[] al_msg = receive("alice");
                print("SERVER_CT: " + al_msg);
                final Cipher rsaDec = Cipher.getInstance("RSA");
                rsaDec.init(Cipher.DECRYPT_MODE, bobKP.getPrivate());
                final byte[] decryptedText = rsaDec.doFinal(al_msg);
                print("PT_RSA: " + Agent.hex(decryptedText));
                /* */
            }
        });
        env.add(new Agent("lock") {
            public void task() throws Exception {

                final byte[] receivedTextBytes = receive("server");
                final byte[] taggy = receive("server");
                final byte[] salt = receive("server");

                if (verify(receivedTextBytes, taggy, pwd_S_L, salt)) {
                    print("SUCCESS:  -- Integrity verified for Alice's message - " + new String(receivedTextBytes, StandardCharsets.UTF_8));
                } else {
                    print("FAILURE -- Integrity check failed for Alice's message!");
                }




            }
        });

        env.connect("alice", "server");
        env.connect("alice", "lock");
        env.connect("server", "lock");
        env.start();
    }

    /**
     * Verifies the MAC tag.
     *
     * @param payload  the message
     * @param tag      the MAC tag
     * @param password the password form which MAC key is derived
     * @param salt     the salt used to strengthen the password
     * @return true iff. the verification succeeds, false otherwise
     */
    public static boolean verify(byte[] payload, byte[] tag, String password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 1000, 256);
        SecretKeySpec secretKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "HmacSHA256");

        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKey);

        byte[] computedTag = mac.doFinal(payload);

        return MessageDigest.isEqual(computedTag, tag);
    }


    /**
     * Computes the MAC tag over the message.
     *
     * @param payload  the message
     * @param password the password form which MAC key is derived
     * @param salt     the salt used to strengthen the password
     * @return the computed tag
     */
    public static byte[] mac(byte[] payload, String password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256"); // password based key
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 1000, 256);
        SecretKeySpec secretKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "HmacSHA256");

        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKey);

        return mac.doFinal(payload);
    }

    /**
     * Hashes the given payload multiple times.
     *
     * @param times   the number of times the value is hashed
     * @param payload the initial value to be hashed
     * @return the final hash value
     */

    public static byte[] hash(int times, byte[] payload) throws Exception {

        final MessageDigest digestAlgorithm = MessageDigest.getInstance("SHA-256");
        byte[] hashed = digestAlgorithm.digest(payload);
        for (int i = 0; i < times; i++){
            hashed = digestAlgorithm.digest(payload);
        }
        return hashed;
    }



    /**
     * Verifies if the MAC tag is correct and if it was received before the deadline
     *
     * @param token        that was received
     * @param deadline     in UNIX time
     * @param tag          to compare against
     * @param password     used to derive the MAC key
     * @param salt         to increase MAC key's enthropy
     * @param receivedTime UNIX time at which the message was received
     * @return true iff. the mac verifies and the message was received before the deadline
     */
    public static boolean verifyTimed(byte[] token, byte[] deadline, byte[] tag,
                                      String password, byte[] salt, long receivedTime) throws Exception {
        return true;
    }

}
